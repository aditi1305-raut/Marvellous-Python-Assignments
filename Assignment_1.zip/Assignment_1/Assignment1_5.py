'''
Write a program which displays 10 to 1 on screen.
'''

for i in range (10,0,-1):
    print(i)