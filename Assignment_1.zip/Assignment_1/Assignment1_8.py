'''
Write a Program which accept number from user and print that number of "*"
on Screen .
'''

print("Enter the number of '*' : ")
nums = int(input())

print("* "*nums)