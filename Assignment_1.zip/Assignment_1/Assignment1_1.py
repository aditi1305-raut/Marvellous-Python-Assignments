'''
Write a program which contains one function named as Fun().That function should display 
" Hello From Fun" on console.
'''

def Fun():
    print("Hello from Fun.")

Fun()