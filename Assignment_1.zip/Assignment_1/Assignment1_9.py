'''
Write a program which display first 10 even numbers on screen.
'''

for i in range (0,21):
    if i % 2 ==0:
        print(i)

