'''
Write a Program which contains one Function named as Add() which accepts two numbers from users 
and return addition of that two numbers.  

'''
def Add():
    num1 = 11
    num2 = 5

    sum = num1 + num2
    print("Addition of Numbers is: ",sum)

Add()