'''
Write a program which accepts number from user and check whether that the number 
is positive or negative or Zero 
'''

num = int(input("Enter a Number: "))

if num > 0:
    print("The Number is Positive.")

elif num < 0:
    print("The Number is Negative.")

else:
    print("The given Number is zero .")