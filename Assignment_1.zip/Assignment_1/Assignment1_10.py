'''
Write a program which accepts name from user and display length of its name.
'''

print("Enter a Name: ")
name = str(input())

print("The length of Name: ",len(name))