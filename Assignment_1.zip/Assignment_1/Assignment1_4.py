'''
Write a Program which displays 5 times Marvellous on Screen.
'''

for i in range(6):
    print("Marvellous")

